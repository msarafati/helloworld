#ifndef DIFF
#include "header.h"
#include "error.h"
#include "check.h"
vector<string> get_diff(string &hash1,string &hash2);
vector<string> faghat_taghire_omgh(vector<string> &lines,string &branch,string &omgh);
void print_change(vector<string> & lines,char options[26]);
#define DIFF
#endif