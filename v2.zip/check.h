#ifndef CHECK
#include "header.h"
#include "errno.h"
int check_options(string arg1,char options[]);
void check_branch(string branch);
void check_tedad_voroodi(char options[],char* arg[],int &argc);
#define CHECK
#endif