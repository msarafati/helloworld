#ifndef FILE
#include "header.h"
#include "error.h"
#include "check.h"
void create_change_log_in_omgh(vector<string> & lines,string &branch, string &omgh,char options[26]);
vector<string> read_from_file(string path,string branch);
#define FILE
#endif