#ifndef HEADER
#include<iostream>
#include<vector>
#include<string>
#include<stdlib.h>
#include<stdio.h>
#include<fstream>
#include<sstream>
using namespace std;
std::string exec(std::string cmd);
#define HEADER
#endif
